#include "../common/pre_compile.h"

namespace c2 { namespace server { namespace core
{
	namespace constant
	{
		//constexpr uint16_t	c_port{ 5500 };
		const	 char*		c_ip{ "127.0.0.1" };
		//constexpr size_t	c_maximum_ccu{ 64 };
		//constexpr size_t	c_maximum_size{ 64 };
	} // namespace constant

	namespace global
	{
		//constexpr uint16_t port{	};
	} // namespace global


} // namespace core
} // namespace server
} // namespace c2
