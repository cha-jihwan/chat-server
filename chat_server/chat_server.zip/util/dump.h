#pragma once

namespace c2 { namespace server { namespace core
{
	LONG WINAPI exception_filter(EXCEPTION_POINTERS* exceptionInfo);

} // namespace util
} // namespace server
} // namespace c2